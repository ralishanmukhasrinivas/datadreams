package com.example.shopping;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;


public class ShoppingAnalyzer {

	public static void main(String[] args) {
		
    
        String csvFilePath = "C:\\Users\\S555460\\shopping.csv";

      
        String targetCategory = "Clothing";

        try {
            // Read all lines from the CSV file
            Path path = Paths.get(csvFilePath);
            List<String> lines = Files.readAllLines(path);

            // Skip the header line if it exists
            List<String> dataLines = lines.stream().skip(1).collect(Collectors.toList());

            // Goal: Calculate the total purchase amount for the specified category
            double totalPurchaseAmount = dataLines.stream()
                    .filter(line -> line.contains(targetCategory))
                    .mapToDouble(line -> Double.parseDouble(line.split(",")[5])) // Assuming Purchase Amount is at index 5
                    .sum();

            System.out.println("Total purchase amount for " + targetCategory + ": $" + totalPurchaseAmount);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

